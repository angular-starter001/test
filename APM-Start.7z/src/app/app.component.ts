import { Component, OnInit } from "@angular/core";

import { JsonService } from './my.data.service';

@Component({
    selector: "pm-root",
    templateUrl: "./app.component.html",
    styleUrls: ["./app.component.css"],
    providers: [ JsonService ]
})
export class AppComponent implements OnInit {
    title: string = "Angular";
    errorMessage: string = "";

    columnDefs: any[] = [
        { headerName: 'Make', field: 'make', width: 290 },
        { headerName: 'Model', field: 'model', widht: 290 },
        { headerName: 'Price', field: 'price', width: 290 }
    ];


    rowData: any[] = [];

    constructor(private _jsonService: JsonService) {
    }


    ngOnInit(): void {
        this._jsonService.getResponseJson()
                .subscribe(response => {
                    this.rowData = response.List;
                },
                    error => this.errorMessage = <any>error);
    }
}
