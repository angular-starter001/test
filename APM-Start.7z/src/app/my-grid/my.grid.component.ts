import { Component, Input } from "@angular/core";


@Component({
    selector: "my-grid",
    templateUrl: "./my.grid.component.html",
    styleUrls: []
})
export class MyGridComponent {
    @Input() columnDefs: any[];
    @Input() rowData: any[];
}
